import { createClient, SupabaseClient } from "@supabase/supabase-js";

// Cliente do Supabase usado exclusivamente pelo servidor (nunca é enviado ao navegador).
// Usamos a chave secreta (sb_secret_... / service_role), que ignora as políticas de
// Row Level Security — por isso é seguro só quando fica exclusivamente no backend.
//
// Se as variáveis de ambiente não estiverem configuradas (ex: ambiente local de
// desenvolvimento sem Supabase), o cliente fica desativado e o sistema continua
// funcionando com o arquivo local db.json como armazenamento — sem persistência
// entre deploys, mas sem quebrar nada.

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const supabase: SupabaseClient | null =
  SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY
    ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
        auth: { persistSession: false }
      })
    : null;

export const isSupabaseConfigured = supabase !== null;

if (!isSupabaseConfigured) {
  console.warn(
    "[Supabase] SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY não configurados. " +
    "O sistema vai funcionar apenas com o arquivo local db.json (sem persistência entre deploys)."
  );
}
